/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrExceptions_H_
#define xrExceptions_H_
#include "X2C.h"
#include "xmRTS.h"

extern void X2C_doRaise(X2C_XSource);

extern void X2C_XInitHandler(X2C_XHandler);

extern void X2C_XRETRY(void);

extern void X2C_XREMOVE(void);

extern void X2C_XOFF(void);

extern void X2C_XON(void);

extern void X2C_TRAP_FC(long, X2C_pCHAR, unsigned long);

extern void X2C_TRAP_F(long);

extern void X2C_ASSERT_F(unsigned long);

extern void X2C_ASSERT_FC(unsigned long, X2C_pCHAR, unsigned long);

extern void X2C_init_exceptions(void);


#endif /* xrExceptions_H_ */
