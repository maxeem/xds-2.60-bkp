/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xlibOS_H_
#define xlibOS_H_
#include "X2C.h"
#include "xmRTS.h"
#include "ChanConsts.h"
#include "xrInt64.h"

extern unsigned long X2C_EnvStringLength(X2C_pCHAR);

extern void X2C_EnvString(X2C_pCHAR, X2C_pCHAR, unsigned long);

extern char X2C_Exists(X2C_pCHAR);

extern void X2C_ModifyTime(X2C_pCHAR, unsigned long *, char *);

extern void X2C_SetFileTime(X2C_pCHAR, unsigned long);

extern int X2C_Remove(X2C_pCHAR);

extern int X2C_Rename(X2C_pCHAR, X2C_pCHAR);

extern void X2C_FullName(X2C_pCHAR, unsigned long, X2C_pCHAR);

struct X2C_TimeStruct;


struct X2C_TimeStruct {
   unsigned long year;
   unsigned long month;
   unsigned long day;
   unsigned long hour;
   unsigned long min0;
   unsigned long sec;
   unsigned long fracs;
   long zone;
   char stf;
};

extern char X2C_CanGetTime(void);

extern char X2C_CanSetTime(void);

extern void X2C_GetTime(struct X2C_TimeStruct *);

extern void X2C_SetTime(struct X2C_TimeStruct *);

extern unsigned long X2C_FracsPerSec(void);

extern long X2C_TimeCompare(struct X2C_TimeStruct, struct X2C_TimeStruct);

extern unsigned long X2C_TimeDayInt(struct X2C_TimeStruct,
                struct X2C_TimeStruct);

extern unsigned long X2C_TimeSecInt(struct X2C_TimeStruct,
                struct X2C_TimeStruct);

extern void X2C_TimeDayAdd(struct X2C_TimeStruct, unsigned long,
                struct X2C_TimeStruct *);

extern void X2C_TimeSecAdd(struct X2C_TimeStruct, unsigned long,
                struct X2C_TimeStruct *);

extern unsigned long X2C_TimeDayNum(unsigned long, unsigned long,
                unsigned long);

#define X2C_fSeekSet 0

#define X2C_fSeekCur 1

#define X2C_fSeekEnd 2

extern unsigned long X2C_fAccessRead;

extern unsigned long X2C_fAccessWrite;

extern unsigned long X2C_fModeNew;

extern unsigned long X2C_fModeText;

extern unsigned long X2C_fModeRaw;

typedef void *X2C_OSFHANDLE;

typedef struct X2C_int64 X2C_FPOS;

#define X2C_MAXXATTRS 8

typedef unsigned long X2C_FXATTRS[8];

extern char X2C_IsMixAllowed(void);

extern void X2C_fGetXAttrs(X2C_FXATTRS);

extern void X2C_fSetXAttrs(X2C_FXATTRS);

extern unsigned char X2C_fOpen(X2C_OSFHANDLE *, char [], unsigned long);

extern int X2C_fClose(X2C_OSFHANDLE *);

extern int X2C_fRead(X2C_OSFHANDLE, X2C_ADDRESS, unsigned long,
                unsigned long *);

extern int X2C_fWrite(X2C_OSFHANDLE, X2C_ADDRESS, unsigned long,
                unsigned long *);

extern int X2C_fSeek(X2C_OSFHANDLE, struct X2C_int64 *, int);

extern int X2C_fTell(X2C_OSFHANDLE, struct X2C_int64 *);

extern int X2C_fSize(X2C_OSFHANDLE, struct X2C_int64 *);

extern int X2C_fFlush(X2C_OSFHANDLE);

extern int X2C_fChSize(X2C_OSFHANDLE);

#define X2C_fStdIn 0

#define X2C_fStdOut 1

#define X2C_fStdErr 2

extern int X2C_fGetStd(X2C_OSFHANDLE *, int);

extern int X2C_fSetStd(X2C_OSFHANDLE, int);

#define X2C_ftDisk 0

#define X2C_ftChar 1

#define X2C_ftPipe 2

#define X2C_ftUnk 3

extern int X2C_fGetFileType(X2C_OSFHANDLE);

extern long X2C_Execute(X2C_pCHAR, X2C_pCHAR, int, unsigned long *);

extern long X2C_ttyReadNE(X2C_ADDRESS, unsigned long, unsigned long *);

extern long X2C_ttyReadLE(X2C_ADDRESS, unsigned long, unsigned long *);

extern long X2C_ttyWrite(X2C_ADDRESS, unsigned long);

extern long X2C_InitTTY(void);

#define X2C_DirSysAreaSize 1024

struct X2C_Dir;


struct X2C_Dir {
   char sys[1024];
   unsigned long namelen;
   unsigned long size;
   struct X2C_TimeStruct cretime;
   struct X2C_TimeStruct mdftime;
   char is_dir;
   char done;
};

extern void X2C_DirOpen(struct X2C_Dir *, X2C_pCHAR);

extern void X2C_DirClose(struct X2C_Dir *);

extern void X2C_DirNext(struct X2C_Dir *);

extern void X2C_DirGetName(struct X2C_Dir *, X2C_pCHAR, unsigned long);

extern unsigned long X2C_GetCDNameLength(void);

extern void X2C_GetCDName(X2C_pCHAR, unsigned long);

extern char X2C_SetCD(X2C_pCHAR);

extern char X2C_CreateDirectory(X2C_pCHAR);

extern char X2C_RemoveDirectory(X2C_pCHAR);

extern long X2C_GetDrive(char *);

extern long X2C_SetDrive(char);

extern long X2C_GetDriveCDNameLength(char, unsigned long *);

extern long X2C_GetDriveCDName(char, X2C_pCHAR, unsigned long);

extern long X2C_GetLabel(char, X2C_pCHAR, unsigned long);


#endif /* xlibOS_H_ */
