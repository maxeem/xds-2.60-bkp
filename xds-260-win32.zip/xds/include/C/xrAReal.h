/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrAReal_H_
#define xrAReal_H_
#include "X2C.h"

extern long X2C_ENTIER(double);

extern long X2C_TRUNCI(double, long, long);

extern unsigned long X2C_TRUNCC(double, unsigned long, unsigned long);


#endif /* xrAReal_H_ */
