/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrStrCmp_H_
#define xrStrCmp_H_
#include "X2C.h"
#include "xmRTS.h"

extern int X2C_STRCMP_PROC(X2C_pVOID, size_t, X2C_pVOID, size_t);


#endif /* xrStrCmp_H_ */
