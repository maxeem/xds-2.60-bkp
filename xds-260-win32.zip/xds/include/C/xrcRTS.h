/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcRTS_H_
#define xrcRTS_H_
#include "X2C.h"
#include "xmRTS.h"

extern char X2C_IN(unsigned long, unsigned short, unsigned long);

extern unsigned long X2C_SET(unsigned long, unsigned long, unsigned short);

extern void X2C_PCOPY(X2C_pVOID *, size_t);

extern void X2C_PFREE(X2C_pVOID);

extern short X2C_PROT(void);


#endif /* xrcRTS_H_ */
