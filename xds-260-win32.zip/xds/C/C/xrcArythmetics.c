/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcArythmetics.c Nov  2 23:50:07 2022" */
#include "xrcArythmetics.h"
#define xrcArythmetics_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern long X2C_REM_F(long a, long b)
{
   if (b==0L) X2C_TRAP(6L);
   if (a>=0L) {
      if (b>0L) return (a%b);
      else return (a%(-b));
   }
   else if (b>0L) return (-((-a)%b));
   else return (-(-a)%(-b));
   return 0L;
} /* end X2C_REM_F() */


extern long X2C_QUO_F(long a, long b)
{
   if (b==0L) X2C_TRAP(6L);
   if (a>=0L) {
      if (b>0L) return (a/b);
      else return (-(a/(-b)));
   }
   else if (b>0L) return (-((-a)/b));
   else return ((-a)/(-b));
   return 0L;
} /* end X2C_QUO_F() */


extern long X2C_MOD_F(long a, long b)
{
   long c;
   if (b<=0L) X2C_TRAP(6L);
   c = (a % b);
   if (a<0L && c<0L) c += b;
   return c;
} /* end X2C_MOD_F() */


extern long X2C_DIV_F(long a, long b)
{
   long c;
   if (b<=0L) X2C_TRAP(6L);
   c = (a/b);
   if (a<0L && c*b>a) --c;
   return c;
} /* end X2C_DIV_F() */


extern float X2C_DIVR_F(float a, float b)
{
   if (b==0.0f) X2C_TRAP(8L);
   else return (a/b);
   return 0.0f;
} /* end X2C_DIVR_F() */


extern double X2C_DIVL_F(double a, double b)
{
   if (b==0.0) X2C_TRAP(8L);
   else return (a/b);
   return 0.0;
} /* end X2C_DIVL_F() */


extern signed char X2C_ABS_INT8(signed char x)
{
   if (x>=0) return x;
   if (x==-128) X2C_TRAP(1L);
   return -x;
} /* end X2C_ABS_INT8() */


extern short X2C_ABS_INT16(short x)
{
   if (x>=0) return x;
   if (x==-32768) X2C_TRAP(1L);
   return -x;
} /* end X2C_ABS_INT16() */


extern long X2C_ABS_INT32(long x)
{
   if (x>=0L) return x;
   if (x==X2C_min_longint) X2C_TRAP(1L);
   return -x;
} /* end X2C_ABS_INT32() */

