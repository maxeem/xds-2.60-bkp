/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtNL.c Nov  2 23:50:07 2022" */
#include "xosFmtNL.h"
#define xosFmtNL_C_
#include "xPOSIX.h"


extern void X2C_StdOutN(void)
{
   printf("\n");
} /* end X2C_StdOutN() */

