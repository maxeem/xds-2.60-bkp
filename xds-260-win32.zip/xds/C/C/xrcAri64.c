/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcAri64.c Nov  2 23:50:07 2022" */
#include "xrcAri64.h"
#define xrcAri64_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern X2C_INT64 X2C_REM64_F(X2C_INT64 a, X2C_INT64 b)
{
   if (b==0i64) X2C_TRAP(6L);
   if (a>=0i64) {
      if (b>0i64) return (a%b);
      else return (a%(-b));
   }
   else if (b>0i64) return (-((-a)%b));
   else return (-(-a)%(-b));
   return 0i64;
} /* end X2C_REM64_F() */


extern X2C_INT64 X2C_QUO64_F(X2C_INT64 a, X2C_INT64 b)
{
   if (b==0i64) X2C_TRAP(6L);
   if (a>=0i64) {
      if (b>0i64) return (a/b);
      else return (-(a/(-b)));
   }
   else if (b>0i64) return (-((-a)/b));
   else return ((-a)/(-b));
   return 0i64;
} /* end X2C_QUO64_F() */


extern X2C_INT64 X2C_MOD64_F(X2C_INT64 a, X2C_INT64 b)
{
   X2C_INT64 c;
   if (b<=0i64) X2C_TRAP(6L);
   c = (a % b);
   if (a<0i64 && c<0i64) c += b;
   return c;
} /* end X2C_MOD64_F() */


extern X2C_INT64 X2C_DIV64_F(X2C_INT64 a, X2C_INT64 b)
{
   X2C_INT64 c;
   if (b<=0i64) X2C_TRAP(6L);
   c = (a/b);
   if (a<0i64 && c*b>a) --c;
   return c;
} /* end X2C_DIV64_F() */


extern X2C_INT64 X2C_ABS_INT64(X2C_INT64 x)
{
   if (x>=0i64) return x;
   if (x==-0x08000000000000000i64) X2C_TRAP(1L);
   return -x;
} /* end X2C_ABS_INT64() */

